# Контракт model.json

- meta: name, niche, slug, date, business_type, currency, unit, horizon, basis, segment, actual_results. parent_url — необязательная ссылка на общий комплект.
- inputs: traffic (входящие/период), conversion (вход→новый покупатель, доля), price (чек), direct (прямые без процентов и резерва), variable_rate (доля), service_reserve (на транзакцию), first_cost (на нового клиента), repeat_cost (на повтор), apc (покупок за согласованный период), cpc (цена входящей единицы), fixed, tracking, target_profit (за тот же период), preparation (разово). ctr, lead_rate, activation_rate и параметры рекомендаций имеют явные знаменатели.
- capacity: enabled; если true — teams, days, orders_per_day, reserve_rate. Не подставляй случайную мощность, если ограничение не оценено.
- cost_items: необязательная расшифровка direct; сумма совпадает с direct.
- retention: доли исходной когорты по возрасту, индекс0=1. Это профиль покупок, не универсальная вероятность жизни.
- canvas: ровно 9 id: partners, activities, resources, value, relations, channels, segments, costs, revenue. name,headline,points[],metric,next,evidence.
- value_map: jobs[],pains[],gains[],products[],relievers[],creators[]; awareness_ladder: level,question,content,measure.
- hypotheses: id,title,stage,hypothesis,metric,target,scores[I,C,E],reason,sample,first,time,cash,evidence. Факт теста отдельно.
- processes: 8 этапов; sources: name,url,kind, при необходимости дата и статус доступа.
- parameter_status: происхождение параметров. copy: отраслевые пояснения, например repeat_need и activation_definition.

Стандартный экран рассчитан на помесячную модель, рубли и APC=1 для первой покупки. Для другой валюты, периода или базового APC сначала адаптируй подписи, когортную модель и проверки. Валидатор запрещает публиковать стандартный экран с другим базовым APC.

Если вход — заявки, переименуй CPC в CPL и обнови экран. APC и LTV требуют горизонта. Не переноси в новую нишу мебель, город, 18 000 ₽, мастеров и M5/M11 из примера без обоснования. У источника точный URL, у недоступного документа конкретный пробел и влияние.
