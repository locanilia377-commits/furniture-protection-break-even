from pathlib import Path
import argparse,json,subprocess,sys,math,shutil
ap=argparse.ArgumentParser();ap.add_argument('model');ap.add_argument('--engine',required=True);ap.add_argument('--node',default=shutil.which('node'));a=ap.parse_args()
m=json.loads(Path(a.model).read_text());errors=[]
def require(ok,msg):
 if not ok:errors.append(msg)
for k in ['name','niche','slug','business_type','currency','unit','horizon','basis','segment']:require(bool(m.get('meta',{}).get(k)),'Missing meta.'+k)
expected={'partners','activities','resources','value','relations','channels','segments','costs','revenue'}
require(set(x.get('id') for x in m.get('canvas',[]))==expected and len(m.get('canvas',[]))==9,'Canvas needs exactly nine unique blocks')
for b in m.get('canvas',[]):
 for k in ['name','headline','points','metric','next','evidence']:require(bool(b.get(k)),'Canvas '+str(b.get('id'))+' missing '+k)
for k in ['jobs','pains','gains','products','relievers','creators']:require(bool(m.get('value_map',{}).get(k)),'Missing value_map.'+k)
require(bool(m.get('sources')),'Sources missing')
require(len(m.get('hypotheses',[]))>=3,'At least three specific hypotheses needed for full release')
require(len(m.get('awareness_ladder',[]))==5,'Awareness ladder needs five explicit stages')
require(len(m.get('processes',[]))==8,'Process map needs eight stages')
require(len({h.get('id') for h in m.get('hypotheses',[])})==len(m.get('hypotheses',[])),'Duplicate hypothesis IDs')
for h in m.get('hypotheses',[]):
 require(len(h.get('scores',[]))==3 and all(isinstance(x,(int,float)) and 0<=x<=10 for x in h.get('scores',[])),'ICE must have three scores in 0..10')
require(m['inputs']['apc']==1,'Standard dashboard uses APC=1 for first-purchase cohort; adapt the period/cohort view before publishing another APC')
if m.get('cost_items'):require(abs(sum(x['value'] for x in m['cost_items'])-m['inputs']['direct'])<.01,'Cost detail does not match direct')
for k in ['lead_rate','activation_rate','ctr','referral_participation','referral_conversion']:
 v=m['inputs'].get(k,0);require(isinstance(v,(int,float)) and 0<=v<=1,'Invalid fraction '+k)
if m['inputs'].get('lead_rate',0)*m['inputs'].get('activation_rate',0)>0:
 require(m['inputs']['conversion']<=m['inputs']['lead_rate']*m['inputs']['activation_rate']+1e-10,'Paid buyers exceed activation in event funnel')
if errors:print(json.dumps({'status':'failed','errors':errors},ensure_ascii=False));sys.exit(1)
if not a.node:raise SystemExit('Resolve Node with load_workspace_dependencies and pass --node')
script=r"""
const fs=require('fs'),E=require(process.argv[1]),m=JSON.parse(fs.readFileSync(process.argv[2])),r=E.calculate(m);
const near=(x,y,t=1e-6)=>{if(!Number.isFinite(x)||Math.abs(x-y)>t)throw Error('Identity failed '+x+' != '+y);};
const i=r.inputs;near(r.profit,r.revenue-r.orders*r.cogs-r.buyers*i.first_cost-r.buyers*(i.apc-1)*i.repeat_cost-r.ac-r.overhead);
for(const row of r.targetRows){if(row.target!==null){near(row.outcome.profit,i.target_profit,.02);if(row.status==='capacity'&&!(row.slots>r.capacity))throw Error('Capacity guard');}else if(row.status!=='impossible')throw Error('Target status');}
const zero=E.calculate(m,{conversion:0});if(zero.cac!==null||zero.fullCac!==null)throw Error('Zero customer guard');
const noProfit=E.calculate(m,{price:0});if(noProfit.fixedOrders!==null)throw Error('Nonpositive contribution guard');
let threw=false;try{E.calculate(m,{price:-1});}catch{threw=true;}if(!threw)throw Error('Invalid patch not rejected');
const summary={status:'passed',checks:['revenue-cost-profit identity','target substitution','capacity classification','zero buyers','nonpositive contribution','invalid values rejected'],profit:r.profit,unit:r.unit,targetCM:r.targetCM,fixedOrders:r.fixedOrders,constantCacOrders:r.constantCac,capacity:r.capacity,targets:r.targetRows.map(x=>({key:x.key,target:x.target,status:x.status,slots:x.slots}))};console.log(JSON.stringify(summary));
"""
run=subprocess.run([a.node,'-e',script,str(Path(a.engine).resolve()),str(Path(a.model).resolve())],capture_output=True,text=True)
if run.returncode:print(run.stderr);sys.exit(1)
print(run.stdout.strip())

