from pathlib import Path
import json,sys,shutil,html
def render(model_file,output_dir,assets=None):
 model_file=Path(model_file);out=Path(output_dir);out.mkdir(parents=True,exist_ok=True)
 assets=Path(assets) if assets else (Path(__file__).resolve().parents[1]/'assets/dashboard' if Path(__file__).resolve().parent.name=='scripts' else Path(__file__).resolve().parent/'assets')
 m=json.loads(model_file.read_text())
 payload=json.dumps(m,ensure_ascii=False).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
 template=assets/'dashboard.template'
 s=template.read_text().replace('__TITLE__',html.escape(m['meta']['name'])).replace('__MODEL_JSON__',payload)
 # A delivered HTML must work on its own, including through file://.
 # Inline scripts run immediately: put them after the embedded model data.
 import re
 s=re.sub(r'<link rel="stylesheet" href="model\.css[^\"]*">','<style>'+ (assets/'model.css').read_text()+'</style>',s)
 s=re.sub(r'<script src="(?:engine|model)\.js[^\"]*" defer></script>','',s)
 s=re.sub(r'<a class="btn optional" href="__PARENT_URL__">.*?</a>','',s)
 s=s.replace('<a href="model.json" download>Данные модели ↓</a>','<button class="btn" id="download-model">Данные модели ↓</button>')
 s=s.replace('<a href="access-audit.html">Что с доступами ↗</a>','<button class="btn" id="access-audit">Что с доступами ↗</button>')
 s=s.replace('Исходные параметры доступны в model.json.','Все параметры встроены в этот файл.')
 scripts=''.join('<script>'+ (assets/name).read_text().replace('</script','<\\/script')+'</script>' for name in ['engine.js','model.js'])
 s=s.replace('</body>',scripts+'</body>')
 if re.search(r'__(?:TITLE|MODEL_JSON|PARENT_URL)__',s):raise ValueError('Unresolved output template marker')
 (out/'index.html').write_text(s)
 for x in ['engine.js','model.js','model.css']:shutil.copy2(assets/x,out/x)
 shutil.copy2(model_file,out/'model.json')
 rows=m.get('access_audit',[])
 audit='<h1>Доступы и исходные данные</h1><p>Дополнительный вход нужен только там, где конкретный материал действительно недоступен.</p><div class="table-wrap"><table><thead><tr><th>Материал</th><th>Статус</th><th>Влияние</th><th>Действие</th></tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(r.get(k,'')))+'</td>' for k in ['item','status','impact','action'])+'</tr>' for r in rows)+'</tbody></table></div>'
 (out/'access-audit.html').write_text('<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Доступы — '+html.escape(m['meta']['name'])+'</title><style>'+(assets/'model.css').read_text()+'</style><main class="shell" style="padding-top:30px;padding-bottom:40px"><a href="index.html">← К визуальной модели</a><div style="margin:30px 0">'+audit+'</div></main></html>')
 return out
if __name__=='__main__':
 if len(sys.argv)<3:raise SystemExit('Usage: render_dashboard.py model.json output-dir [assets-dir]')
 print(render(*sys.argv[1:]))

