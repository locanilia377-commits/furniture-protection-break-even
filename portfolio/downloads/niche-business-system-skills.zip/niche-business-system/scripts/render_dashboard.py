from pathlib import Path
import json,sys,shutil,html
def render(model_file,output_dir,assets=None):
 model_file=Path(model_file);out=Path(output_dir);out.mkdir(parents=True,exist_ok=True)
 assets=Path(assets) if assets else (Path(__file__).resolve().parents[1]/'assets/dashboard' if Path(__file__).resolve().parent.name=='scripts' else Path(__file__).resolve().parent/'assets')
 m=json.loads(model_file.read_text())
 payload=json.dumps(m,ensure_ascii=False).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
 s=(assets/'index.template.html').read_text().replace('__TITLE__',html.escape(m['meta']['name'])).replace('__MODEL_JSON__',payload).replace('__PARENT_URL__',html.escape(m['meta'].get('parent_url','index.html'),quote=True))
 (out/'index.html').write_text(s)
 for x in ['engine.js','model.js','model.css']:shutil.copy2(assets/x,out/x)
 shutil.copy2(model_file,out/'model.json')
 rows=m.get('access_audit',[])
 audit='<h1>Доступы и исходные данные</h1><p>Дополнительный вход нужен только там, где конкретный материал действительно недоступен.</p><div class="table-wrap"><table><thead><tr><th>Материал</th><th>Статус</th><th>Влияние</th><th>Действие</th></tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(r.get(k,'')))+'</td>' for k in ['item','status','impact','action'])+'</tr>' for r in rows)+'</tbody></table></div>'
 (out/'access-audit.html').write_text('<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Доступы — '+html.escape(m['meta']['name'])+'</title><link rel="stylesheet" href="model.css?v=20261116-v6"><main class="shell" style="padding-top:30px;padding-bottom:40px"><a href="index.html">← К визуальной модели</a><div style="margin:30px 0">'+audit+'</div></main></html>')
 return out
if __name__=='__main__':
 if len(sys.argv)<3:raise SystemExit('Usage: render_dashboard.py model.json output-dir [assets-dir]')
 print(render(*sys.argv[1:]))

