(()=>{
'use strict';
const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
const fmt=(n,d=0)=>Number.isFinite(n)?new Intl.NumberFormat('ru-RU',{maximumFractionDigits:d}).format(n):'—',money=(n,d=0)=>fmt(n,d)+' ₽',pct=(n,d=1)=>Number.isFinite(n)?fmt(n*100,d)+'%':'—',clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
let m;
try{m=JSON.parse($('#model-data').textContent);}catch(error){
 document.title='Модель не подготовлена';
 $('#content').innerHTML='<section class="panel" role="alert"><h2>Открыт исходный шаблон</h2><p>Этот файл ещё не содержит данных модели. Откройте готовый файл «Защита_мебели_Модель_бизнеса.html» из комплекта.</p></section>';
 return;
}
let original=JSON.parse(JSON.stringify(m)),r,selectedMetric='conversion',active='canvas',hyp='H01',currentCanvasBlocks=[];
const states={candidate:['Кандидат на проверку',''],capacity:['Не помещается в мощность','warn'],impossible:['Недостижимо одним рычагом','bad'],horizon:['Требуется окно повторов','warn']};
const head=(title,sub,badge='Типовые значения')=>'<div class="pane-head"><div><h2>'+title+'</h2><p>'+sub+'</p></div><span class="pill">'+badge+'</span></div>';
const list=items=>'<ul>'+items.map(x=>'<li>'+esc(x)+'</li>').join('')+'</ul>';
function canvas(){
 const blocks=JSON.parse(JSON.stringify(m.canvas));
 for(const b of blocks){
 if(b.id==='resources')b.metric=fmt(r.grossCapacity)+' валовых → '+fmt(r.capacity)+' плановых слотов';
 if(b.id==='channels')b.metric='CPC '+money(r.inputs.cpc)+' → медиа-CAC '+money(r.cac);
 if(b.id==='costs'){b.points=[money(r.cogs)+' прямых на заказ с сервисным резервом',money(r.inputs.first_cost)+' первая продажа; '+money(r.ac)+' медиа/месяц',money(r.inputs.fixed)+' постоянных + '+money(r.inputs.tracking)+' сопровождения'];b.metric='Сервисный резерв '+money(r.inputs.service_reserve)+' на заказ';}
 if(b.id==='revenue'){b.headline=money(r.inputs.price)+' за стандартный заказ';b.points=[fmt(r.orders,1)+' заказов → '+money(r.revenue)+' выручки','Новая потребность прежнего клиента — отдельная покупка','Другой сегмент требует отдельной модели'];}
 }
 currentCanvasBlocks=blocks;
 return head('Канва бизнес-модели Остервальдера','Девять блоков показывают, кому, какую ценность и за счёт каких ресурсов продаёт бизнес. Нажмите на блок — увидите его проверку.')+'<div class="canvas" aria-label="Канва бизнес-модели: девять блоков">'+blocks.map((b,i)=>'<button class="canvas-block '+b.id+'" data-canvas="'+b.id+'" aria-label="'+esc(b.name)+': открыть подробности"><span class="block-kicker"><b>'+esc(b.name)+'</b><span>'+String(i+1).padStart(2,'0')+'</span></span><h3>'+esc(b.headline)+'</h3>'+list(b.points)+'<span class="block-foot">'+esc(b.metric)+' ↗</span></button>').join('')+'</div><p class="caption">Структура канвы — Osterwalder & Pigneur / Strategyzer. Содержание блоков — модель для выбранной ниши; гипотезы требуют проверки.</p>';
}
function value(){
 const v=m.value_map;
 return head('Клиент ↔ ценностное предложение','Проверяем, соответствует ли услуга задачам клиента, его опасениям и желаемым результатам. Это гипотезы для интервью.')+
 '<div class="vpc-map"><div class="vpc-stack"><div class="vpc-item gain"><h3>Создаём выгоды</h3>'+list(v.creators)+'</div><div class="vpc-item job"><h3>Продукты и услуги</h3>'+list(v.products)+'</div><div class="vpc-item pain"><h3>Снижаем опасения</h3>'+list(v.relievers)+'</div></div><div class="vpc-middle" aria-hidden="true">⇄</div><div class="vpc-stack"><div class="vpc-item gain"><h3>Желаемые выгоды клиента</h3>'+list(v.gains)+'</div><div class="vpc-item job"><h3>Задачи клиента</h3>'+list(v.jobs)+'</div><div class="vpc-item pain"><h3>Опасения и трудности</h3>'+list(v.pains)+'</div></div></div><h3 class="section-title">Лестница осведомлённости Бена Ханта</h3><div class="ladder">'+m.awareness_ladder.map((x,i)=>'<div><b>0'+(i+1)+'</b><h3>'+esc(x.level)+'</h3><p>'+esc(x.question)+'</p><small>'+esc(x.content)+'<br><br>Измеряем: '+esc(x.measure)+'</small></div>').join('')+'</div>';
}
function metricValue(v,unit){return v===null?'—':unit==='ratio'?pct(v,3):unit==='money'?money(v,2):unit==='times'?fmt(v,3)+'×':fmt(v,1);}
function metricDetail(){
 const x=r.targetRows.find(x=>x.key===selectedMetric)||r.targetRows[1],s=states[x.status];
 let detail=x.note;
 if(x.status==='impossible')detail+=' Требуемое значение '+metricValue(x.rawTarget,x.unit)+' экономически недопустимо. Не подставляем его в рабочую модель.';
 if(x.status==='capacity')detail+=' Для этой цели потребуется около '+fmt(x.slots)+' заказов при '+fmt(r.capacity)+' плановых слотах.';
 if(x.status==='horizon')detail+=' Прибыль первого месяца от будущих покупок не возникает; нужна зрелая когорта или подтверждённый установившийся поток.';
 if(x.status==='candidate')detail+=' Это расчётная цель при неизменности остальных параметров, а не доказанная достижимость.';
 return '<div class="explanation" aria-live="polite"><div><span class="metric-symbol">'+esc(x.symbol)+'</span><strong>'+metricValue(x.target,x.unit)+'</strong></div><div><p>'+esc(detail)+'</p><small>Цель вклада до постоянных расходов и сопровождения: '+money(r.targetCM)+'. Чистая цель: '+money(r.inputs.target_profit)+'.</small></div></div>';
}
function khanin(){
 const max=Math.max(...r.sensitivity.map(x=>Math.abs(x.delta||0)),1),traffic=r.targetRows[0],conversion=r.targetRows[1];
 const trafficNote=traffic.target===null?'Рост трафика одним рычагом не даёт допустимой цели.':('При постоянном CPC расчёт требует '+fmt(traffic.slots)+' заказов'+(traffic.status==='capacity'?' и превышает плановую мощность '+fmt(r.capacity)+'.':r.capacity===null?'; мощность ещё не оценена.':' и укладывается в плановую мощность '+fmt(r.capacity)+'.'));
 const conversionNote=conversion.target===null?'Цель одним изменением конверсии недостижима.':'Конверсия как один из рычагов: '+pct(r.inputs.conversion,2)+' → '+pct(conversion.target,3)+'.';
 return '<div class="pane-head"><div><h2>Таблица целевых метрик Ханина</h2><p>Меняем по одному параметру. Остальные сохраняем. Отдельно проверяем физическую мощность и срок повторных покупок.</p></div><label class="goal-label">Цель прибыли, ₽ / месяц<input id="goal-control" type="number" min="0" step="1000" value="'+r.inputs.target_profit+'"></label></div>'+
 '<div class="table-wrap"><table><thead><tr><th>Метрика</th><th>Сейчас</th><th>Для цели</th><th>Изменение</th><th>Заказов / период</th><th>Проверка</th></tr></thead><tbody>'+r.targetRows.map(x=>{
 const s=states[x.status],change=x.target!==null&&x.current!==0?(x.target/x.current-1):null;
 return '<tr data-metric="'+x.key+'" class="'+(selectedMetric===x.key?'selected':'')+'"><td><span class="metric-name">'+esc(x.label)+'</span><span class="metric-symbol">'+esc(x.symbol)+'</span></td><td class="num">'+metricValue(x.current,x.unit)+'</td><td class="num"><b>'+metricValue(x.target,x.unit)+'</b></td><td class="num">'+(change===null?'—':(change>0?'+':'')+pct(change,1))+'</td><td class="num">'+(x.slots===null?'—':fmt(x.slots)+(x.mode==='cohort'?'*':''))+'</td><td><span class="pill '+s[1]+'">'+s[0]+'</span></td></tr>';
 }).join('')+'</tbody></table></div><div id="metric-detail">'+metricDetail()+'</div><h3 class="section-title">Изменение на 10%: прибавка к месячной прибыли</h3><div class="panel"><div class="bar-chart" role="img" aria-label="Чувствительность прибыли к изменению одного параметра на десять процентов">'+r.sensitivity.map(x=>'<div class="bar-row"><span>'+esc(x.label)+'</span><span class="bar-track"><i style="width:'+Math.abs(x.delta)/max*100+'%"></i></span><b>'+(Number.isFinite(x.delta)&&x.delta>=0?'+':'')+money(x.delta)+'</b></div>').join('')+'</div><p class="caption">Это сравнение арифметического эффекта. Лёгкость изменения, качество трафика и спрос проверяются отдельно.</p></div><div class="callout">'+conversionNote+' '+trafficNote+' Выбор рычага требует проверки спроса, качества и управляемости параметра.</div>';
}
function repeatPoints(){return m.retention.flatMap((rate,age)=>age>0&&rate>0?[{rate,age}]:[]);}
function funnel(){
 const repeats=repeatPoints(),repeatText=repeats.map(x=>'M'+x.age+': '+pct(x.rate)).join(' · ')||'Повторы не заложены';
 const i=r.inputs,leadToActive=r.leads>0?r.activated/r.leads:null,activeToPaid=r.activated>0?r.buyers/r.activated:null,k=i.referral_participation*i.invites_per_referrer*i.referral_conversion;
 const flow=[['Awareness','Посетители',r.inputs.traffic,'100%'],['Acquisition','Пригодные контакты',r.leads,pct(i.lead_rate)],['Activation','Поняли предложение',r.activated,pct(leadToActive)],['Revenue','Оплатили и получили услугу',r.buyers,pct(activeToPaid)]];
 return head('Пиратская воронка AAARRR','События, конверсии и следующий шаг по каждому этапу. Удержание и рекомендации — отдельные ветви после первой покупки.')+
 '<div class="funnel-layout"><div><div class="awareness"><div><span>Показы предложения</span><b>'+fmt(r.impressions)+'</b></div><div><span>CTR · показ → посетитель</span><b>'+pct(i.ctr)+'</b></div></div><div class="funnel">'+flow.map((x,n)=>'<button class="funnel-stage" style="--w:'+[100,88,77,65][n]+'%" data-stage="'+n+'"><small>'+x[0]+' · '+x[1]+'</small><b>'+fmt(x[2],1)+'</b><span>'+x[3]+'</span></button>'+(n<3?'<span class="flow-arrow">↓ следующий измеримый переход</span>':'')).join('')+'</div><p class="caption">Ширина блоков схематическая; конверсии подписаны. Activation = '+esc(m.copy?.activation_definition||'полученная клиентом первая ценность')+'. Новые типовые параметры: '+pct(i.activation_rate)+' контактов активируются.</p></div><div class="stage-cards"><div class="stage-card"><span class="letter">R</span><h3>Retention · повторная потребность</h3><b>'+repeatText+'</b><p>'+esc(m.copy?.repeat_need||'Повтор — новая покупка того же клиента. Переделка и второй платёж за прежний заказ сюда не входят.')+'</p><small>Знаменатель — исходная когорта покупателей. Окно наблюдения должно достигнуть указанного возраста когорты; M0 — первая покупка.</small></div><div class="stage-card"><span class="letter">R</span><h3>Referral · новый клиент по рекомендации</h3><b>K = '+fmt(k,2)+'</b><p>'+pct(i.referral_participation)+' клиентов × '+fmt(i.invites_per_referrer)+' приглашения × '+pct(i.referral_conversion)+' покупок.</p><small>Все три параметра типовые. Прогноз '+fmt(r.buyers*k,1)+' нового клиента на исходную группу; не добавляем его к повторным заказам.</small></div><div class="stage-card"><h3>Связь с экономикой</h3><p>'+fmt(i.traffic)+' × '+pct(i.conversion,2)+' = '+fmt(r.buyers)+' новых покупателей.</p><p>Медиа-CAC '+money(r.cac)+'. Вклад до рекламы '+money(r.unit)+'.</p></div></div></div>'+(activeToPaid>1?'<div class="callout">Сценарий событий несогласован: покупателей больше, чем активированных клиентов. Пересмотрите этапные конверсии перед использованием.</div>':'');
}
function lineChart(values,capacity){
 const w=820,h=210,pad=40,top=18,bottom=170,max=Math.max(...values,capacity||0,1)*1.15,step=(w-pad*2)/Math.max(1,values.length-1);
 const y=v=>bottom-v/max*(bottom-top),points=values.map((v,n)=>(pad+n*step)+','+y(v)).join(' ');
 let svg='<svg class="growth-line" viewBox="0 0 820 210" role="img" aria-label="Прогноз заказов по месяцам и плановая мощность"><line x1="40" y1="'+bottom+'" x2="780" y2="'+bottom+'" stroke="#ccd5c6"/>';
 if(capacity!==null)svg+='<line x1="40" y1="'+y(capacity)+'" x2="780" y2="'+y(capacity)+'" stroke="#a46e47" stroke-dasharray="5 4"/><text x="780" y="'+(y(capacity)-8)+'" text-anchor="end">Мощность '+fmt(capacity)+'</text>';
 svg+='<polyline points="'+points+'" fill="none" stroke="#3f7052" stroke-width="3"/>';
 values.forEach((v,n)=>{svg+='<circle cx="'+(pad+n*step)+'" cy="'+y(v)+'" r="4" fill="#3f7052"/>';if([0,Math.floor((values.length-1)/2),values.length-1].includes(n))svg+='<text x="'+(pad+n*step)+'" y="'+(y(v)-10)+'" text-anchor="middle">'+fmt(v,1)+'</text>';svg+='<text x="'+(pad+n*step)+'" y="197" text-anchor="middle">М'+(n+1)+'</text>';});return svg+'</svg>';
}
function unit(){
 const i=r.inputs,baseDirect=i.direct+i.price*i.variable_rate,perOverhead=r.buyers>0?r.overhead/r.buyers:null;
 const vals=[['Цена заказа',0,i.price],['Прямые расходы',baseDirect,i.price-baseDirect],['Сервисный резерв',i.service_reserve,r.gross],['Первая продажа',i.first_cost,r.unit],['Привлечение',r.cac,r.cac===null?null:r.unit-r.cac],['Постоянные и сопровождение',perOverhead,perOverhead===null?null:r.unit-r.cac-perOverhead]];
 const cap=r.grossCapacity===null?0:Math.min(r.grossCapacity,150),slots=Array.from({length:cap},(_,n)=>'<i class="slot '+(n>=r.capacity?'reserve':n<r.fixedOrders?'used':'empty')+'" aria-hidden="true"></i>').join('');
 return head('Экономика одного заказа и предел роста','Показываем, что остаётся от чека после каждой статьи, и сколько заказов можно принять в выбранный период.')+
 '<div class="cards2"><div class="panel"><h3>Что остаётся от '+money(i.price)+'</h3><div class="unit-flow">'+vals.map((x,n)=>'<div class="unit-row"><label>'+x[0]+'<span>'+(n===0?'получено':x[1]===null?'нет базы распределения':'−'+money(x[1]))+'</span></label><span class="bar-track"><i style="width:'+clamp((x[2]||0)/Math.max(1,i.price)*100,0,100)+'%"></i></span><b>'+money(x[2])+'</b></div>').join('')+'</div><p class="caption">Шкала показывает остаток от исходного чека. '+fmt(r.buyers)+' заказов × '+money(r.buyers>0?r.profit/r.buyers:null)+' = '+money(r.profit)+' прибыли в месяц.</p></div><div class="panel"><h3>Объём для цели и мощность</h3><strong class="big-number">'+fmt(r.fixedOrders)+' / '+fmt(r.capacity)+'</strong><p>заказов для цели / плановых слотов</p><div class="capacity-grid" role="img" aria-label="Загрузка плановых слотов и резерв времени">'+slots+'</div><div class="legend"><span><i></i>Заказы для цели</span><span><i class="empty"></i>Остаток</span><span><i class="reserve"></i>Резерв</span></div><p class="capacity-message" style="margin-top:20px">Фиксированная реклама: '+fmt(r.fixedOrders)+' заказов. Постоянный медиа-CAC: '+fmt(r.constantCac)+' заказов. Подготовка первого цикла добавляет '+money(i.preparation)+' и требует '+fmt(r.firstOrders)+' заказов.</p><p class="caption">Стоимость сопровождения включена один раз. Денежный сервисный резерв и резерв времени — разные параметры.</p></div></div><h3 class="section-title">Как повторы меняют месячный объём</h3><div class="panel">'+lineChart(r.retained.map(x=>x.total),r.capacity)+'<p class="caption">Прогноз на последовательности одинаковых новых когорт. Это не наблюдённая динамика действующего бизнеса.</p></div>';
}
function retention(){
 const n=m.retention.length,repeats=repeatPoints(),repeatCaption=repeats.length?repeats.map(x=>pct(x.rate)+' на возрасте M'+x.age).join(', ')+' — типовые повторные покупки.':'Повторные покупки в этом профиле не заложены.';
 let table='<div class="table-wrap"><table class="cohort"><thead><tr><th>Новая когорта</th>'+Array.from({length:n},(_,j)=>'<th>М'+(j+1)+'</th>').join('')+'</tr></thead><tbody>';
 for(let c=0;c<n;c++){table+='<tr><td>Когорта '+(c+1)+'</td>';for(let month=0;month<n;month++){const age=month-c;if(age<0)table+='<td class="future">—</td>';else{const v=m.retention[age]||0;table+='<td class="'+(age===0?'initial':v>0?'repeat':'zero')+'">'+(v===0?'0%':pct(v,0))+'</td>';}}table+='</tr>';}table+='</tbody></table></div>';
 return head('Когорты, удержание и LTV','Горизонт '+n+' месяцев. Каждая новая когорта равна '+fmt(r.buyers)+' покупателям. Возврат — отдельная покупка на новую потребность.')+
 '<div class="retention-stats"><div><b>'+fmt(r.apc12,2)+'×</b><span>покупок на клиента за '+n+' месяцев</span></div><div><b>'+money(r.ltv)+'</b><span>LTV по вкладу до полного CAC</span></div><div><b>'+money(r.ltvAfterAcquisition)+'</b><span>вклад LTV после полного CAC</span></div></div>'+table+'<p class="caption">Столбцы — месяцы наблюдения, строки — новые когорты. 100% — первая покупка. '+repeatCaption+' «—» означает когорта ещё не появилась, а не нулевое удержание.</p><div class="cards2" style="margin-top:24px"><div class="panel"><h3>Повторная потребность, а не замена ради частоты</h3><p>'+esc(m.copy?.repeat_need||'Повтор — отдельная новая потребность клиента. Исправление прежней работы не является новой продажей.')+'</p></div><div class="panel"><h3>Почему LTV не равен прибыли месяца</h3><p>LTV объединяет будущие покупки одной когорты. Месячная прибыль учитывает зрелость всех когорт и расходы периода. Прогноз месяца '+n+': '+fmt(r.retained[n-1].total,1)+' заказов и '+money(r.retained[n-1].profit)+' прибыли.</p></div></div>';
}
function experiments(){
 if(!m.hypotheses?.length)return head('ICE → HADI','Гипотезы ещё не подготовлены.')+'<div class="callout">Сначала заполните проверяемые гипотезы и критерии.</div>';
 const rows=m.hypotheses.map(x=>({...x,ice:x.scores.reduce((a,b)=>a+b,0)/3})).sort((a,b)=>b.ice-a.ice||a.id.localeCompare(b.id));
 const x=m.hypotheses.find(x=>x.id===hyp)||m.hypotheses[0];
 return head('ICE → HADI: от идеи к решению','Оценки ICE — типовые приоритеты. Запуск и результаты каждой проверки должны подтверждаться отдельно.')+
 '<div class="table-wrap"><table><thead><tr><th>Гипотеза</th><th>Этап</th><th>I / C / E</th><th>ICE, среднее</th><th>Ресурс</th></tr></thead><tbody>'+rows.map(x=>'<tr data-hyp="'+x.id+'" class="'+(hyp===x.id?'selected':'')+'"><td><span class="metric-name">'+x.id+' · '+esc(x.title)+'</span><span class="metric-symbol">'+esc(x.target)+'</span></td><td>'+esc(x.stage)+'</td><td><span class="ice-bars">'+x.scores.map(v=>'<span style="width:'+v/30*100+'%"></span>').join('')+'</span><span class="metric-symbol">'+x.scores.join(' / ')+'</span></td><td class="num">'+fmt(x.ice,2)+'</td><td class="num">'+fmt(x.time)+' ч · '+money(x.cash)+'</td></tr>').join('')+'</tbody></table></div><h3 class="section-title">'+esc(x.id+' · '+x.title)+'</h3><div class="hadi"><div><span class="letter">H</span><h3>Hypothesis</h3><p>'+esc(x.hypothesis)+'</p><small>Предположение, а не установленная причина</small></div><div><span class="letter">A</span><h3>Action</h3><p>'+esc(x.first)+'</p><small>'+esc(x.sample)+'</small></div><div><span class="letter">D</span><h3>Data</h3><p>'+esc(x.metric)+'</p><small>'+esc(x.target)+'</small></div><div><span class="letter">I</span><h3>Insight</h3><p>Фактический результат пока не внесён.</p><small>'+esc(x.evidence)+'</small></div></div><div class="callout">Решение после данных: повторить, изменить или остановить. Изменение финансового сценария не переписывает автоматически ранее составленный протокол; перед запуском нужно согласовать его параметры.</div>';
}
function processes(){
 return head('Один ввод ниши → восемь процессов','Каждый процесс имеет отдельный навык, вход, выход и критерий приёмки. Общий запуск управляет последовательностью и итоговой проверкой.','Повторяемый шаблон')+
 '<div class="launch"><label>Название следующей ниши<input id="next-niche" placeholder="Например: химчистка мебели" value=""></label><button class="btn primary" id="copy-launch">Скопировать запрос</button></div><p id="launch-status" class="basis" role="status">Отправьте название ниши в чат с установленным набором навыков. Сайт показывает результат и не запускает анализ новой ниши сам.</p>'+
 '<div class="process-grid" style="margin-top:20px">'+m.processes.map(x=>'<article class="process-card"><span class="number">'+x.id+'</span><div><h3>'+esc(x.name)+'</h3><code>$'+esc(x.skill)+'</code><p><b>Вход:</b> '+esc(x.input)+'</p><p><b>Выход:</b> '+esc(x.output)+'</p><p><b>Приёмка:</b> '+esc(x.check)+'</p></div></article>').join('')+'</div><div class="callout">Общий навык: <b>$niche-business-system</b>. Параметры без фактических данных обозначаются как типовые значения модели. Проверка обнаруживает арифметические ошибки, несогласованные периоды и неподтверждённые утверждения; абсолютная безошибочность не обещается.</div>';
}
const renders={canvas,value,khanin,funnel,unit,retention,experiments,processes};
function render(preserveGoal=false){
 r=NicheModel.calculate(m);
 $('#segment').textContent=m.meta.niche+' · '+m.meta.segment+' · '+m.meta.unit;
 $('#profit').textContent=money(r.profit);$('#goal-summary').textContent=money(r.inputs.target_profit);$('#goal-orders').textContent=fmt(r.fixedOrders)+' заказов';$('#capacity-summary').textContent=r.capacity===null?'Не оценена':fmt(r.capacity)+' слотов';
 Object.entries(renders).forEach(([id,fn])=>{const panel=$('#pane-'+id),stable=id==='khanin'&&preserveGoal?panel.querySelector('.pane-head'):null;if(stable){const temp=document.createElement('div');temp.innerHTML=fn();temp.querySelector('.pane-head').remove();Array.from(panel.children).forEach(x=>{if(x!==stable)x.remove();});panel.append(...temp.childNodes);}else panel.innerHTML=fn();});
 const goal=$('#goal-control');if(!goal.dataset.bound){goal.dataset.bound='1';goal.addEventListener('input',e=>{const v=Number(e.target.value);if(e.target.value!==''&&Number.isFinite(v)&&v>=0){e.target.setCustomValidity('');m.inputs.target_profit=v;render(true);}});}
 $('#copy-launch')?.addEventListener('click',async()=>{const niche=$('#next-niche').value.trim();if(!niche){$('#launch-status').textContent='Введите название ниши.';return;}const prompt='$niche-business-system Ниша: '+niche+'. Подготовь весь шаблон: Остервальдер, ценность, экономика, Ханин, AAARRR, удержание, ICE/HADI, процессы и визуальный результат. При отсутствии фактов используй явно отмеченные типовые значения модели.';try{await navigator.clipboard.writeText(prompt);$('#launch-status').textContent='Запрос скопирован. Вставьте его в чат.';}catch{$('#launch-status').textContent=prompt;}});
}
function tab(id){if(!renders[id])return;active=id;document.querySelectorAll('.tab').forEach(x=>x.setAttribute('aria-selected',String(x.dataset.pane===id)));document.querySelectorAll('.pane').forEach(x=>x.hidden=x.id!=='pane-'+id);history.replaceState(null,'','#'+id);}
function open(label,title,content){$('#detail-label').textContent=label;$('#detail-title').textContent=title;$('#detail-content').innerHTML=content;$('#detail').showModal();}
$('#content').addEventListener('click',e=>{
 const block=e.target.closest('[data-canvas]');if(block){const b=currentCanvasBlocks.find(x=>x.id===block.dataset.canvas);open(b.name,b.headline,list(b.points)+'<span class="label">Что измеряем</span><p>'+esc(b.metric)+'</p><span class="label">Следующая проверка</span><p>'+esc(b.next)+'</p><span class="label">Основание</span><p>'+esc(b.evidence)+'</p>');return;}
 const met=e.target.closest('[data-metric]');if(met){selectedMetric=met.dataset.metric;document.querySelectorAll('[data-metric]').forEach(x=>x.classList.toggle('selected',x===met));$('#metric-detail').innerHTML=metricDetail();return;}
 const test=e.target.closest('[data-hyp]');if(test){hyp=test.dataset.hyp;$('#pane-experiments').innerHTML=experiments();return;}
 const stage=e.target.closest('[data-stage]');if(stage){const texts=[['Awareness','Показ → целевой переход','Знаменатель CTR — показы, а не люди. Повторные показы одному человеку не равны новой аудитории.'],['Acquisition','Пригодный контакт','Уникальный контакт соответствует зоне, поверхности и задаче. Дубли и контакты ради файла без предметного запроса считаются отдельно.'],['Activation','Первая понятная ценность','Полученная клиентом первая ценность. Действие продавца само по себе не означает активацию.'],['Revenue','Оплачено и выполнено','Аванс и оборот не равны прибыли. Возвраты, исправления и прямые расходы привязываются к заказу.']][Number(stage.dataset.stage)];open(texts[0],texts[1],'<p>'+texts[2]+'</p>');}
});
document.querySelectorAll('.tab').forEach((b,n)=>{b.addEventListener('click',()=>tab(b.dataset.pane));b.addEventListener('keydown',e=>{const all=[...document.querySelectorAll('.tab')];let j=e.key==='ArrowRight'||e.key==='ArrowDown'?(n+1)%all.length:e.key==='ArrowLeft'||e.key==='ArrowUp'?(n+all.length-1)%all.length:e.key==='Home'?0:e.key==='End'?all.length-1:null;if(j!==null){e.preventDefault();all[j].focus();tab(all[j].dataset.pane);}});});
$('#close-dialog').addEventListener('click',()=>$('#detail').close());$('#print').addEventListener('click',()=>window.print());
$('#download-model')?.addEventListener('click',()=>{const url=URL.createObjectURL(new Blob([JSON.stringify(m,null,2)],{type:'application/json;charset=utf-8'})),link=document.createElement('a');link.href=url;link.download=(m.meta.slug||'business-model')+'.json';document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);});
$('#access-audit')?.addEventListener('click',()=>open('Доступы и исходные данные','Что с доступами','<div class="table-wrap"><table><thead><tr><th>Материал</th><th>Статус</th><th>Влияние</th><th>Действие</th></tr></thead><tbody>'+(m.access_audit||[]).map(row=>'<tr>'+['item','status','impact','action'].map(key=>'<td>'+esc(row[key])+'</td>').join('')+'</tr>').join('')+'</tbody></table></div>'));
$('#sources').addEventListener('click',()=>open('Источники и статусы','На чём построена модель',m.sources.map(s=>'<p><a href="'+esc(s.url)+'" target="_blank" rel="noopener">'+esc(s.name)+'</a><br><span class="basis">'+esc(s.kind)+'</span></p>').join('')+'<p class="basis">'+esc(m.meta.basis)+'</p>'));
$('#edit-inputs').addEventListener('click', () => {
 const fields = [
  ['traffic', 'Посетители / месяц', 'Число целевых переходов за месяц. По нему считаются новые покупатели и расходы на рекламу.'],
  ['conversion', 'Посетитель → покупатель, %', 'Доля посетителей, которые совершили первую покупку. Введите 3,5 для 3,5%. Меняет число новых покупателей.'],
  ['price', 'Средний чек, ₽', 'Средняя выручка за одну продажу. Меняет выручку и расходы, начисляемые в процентах от чека.'],
  ['direct', 'Прямые без процентов и резерва, ₽', 'Затраты на одну продажу в рублях, например материалы, труд или доставка. Вычитаются из чека отдельно от процентных статей и резерва.'],
  ['variable_rate', 'Процентные статьи, %', 'Суммарная доля расходов от чека, например комиссий и платежей. Вычитается из выручки по каждой продаже.'],
  ['service_reserve', 'Сервисный резерв / заказ, ₽', 'Плановая сумма на исправления, возвраты или поддержку по одной продаже. Входит в затраты на каждую продажу.'],
  ['first_cost', 'Первая продажа / клиент, ₽', 'Затраты на доведение клиента до покупки, например консультация или оформление заказа. Списываются один раз на нового покупателя сверх рекламы.'],
  ['cpc', 'CPC, ₽', 'Средняя цена одного перехода. Умножается на переходы и даёт рекламный бюджет месяца.'],
  ['fixed', 'Постоянные / месяц, ₽', 'Постоянные расходы за месяц, например аренда и связь. Вычитаются даже при нуле заказов.'],
  ['tracking', 'Сопровождение / месяц, ₽', 'Отдельный месячный бюджет на ведение модели или проекта. Вычитается из результата месяца. Если уже включён в постоянные расходы, укажите 0.'],
  ['target_profit', 'Цель прибыли / месяц, ₽', 'Желаемая прибыль. Задаёт объём продаж для цели и целевые значения в таблице Ханина.'],
  ['preparation', 'Подготовка разово, ₽', 'Разовые затраты на запуск. Увеличивают объём продаж для цели первого цикла с учётом подготовки.']
 ];
 const percentFields = new Set(['conversion', 'variable_rate']);
 const displayed = Object.fromEntries(fields.map(([key]) => [key, percentFields.has(key)
  ? Number((m.inputs[key] * 100).toPrecision(15))
  : m.inputs[key]]));
 const fieldMarkup = fields.map(([key, label, hint]) => `
  <div class="parameter-field">
   <label for="param-${key}">${label}</label>
   <input id="param-${key}" name="${key}" type="number" min="0" step="any" ${key === 'conversion' ? 'max="100"' : ''}
    required value="${displayed[key]}" aria-describedby="hint-${key}" inputmode="decimal">
   <small id="hint-${key}">${hint}</small>
  </div>`).join('');

 const example = NicheModel.calc(original);
 const salesCosts = example.buyers * (example.inputs.first_cost + (example.inputs.apc - 1) * example.inputs.repeat_cost);
 open('Общие параметры', 'Изменить типовые значения', `
  <section class="params-guide" aria-labelledby="params-guide-title">
   <h3 id="params-guide-title">Как пользоваться</h3>
   <p><b>Единица продажи.</b> ${esc(m.meta.unit || 'Одна покупка')}</p>
   <ol class="params-steps">
    <li>Введите переходы, конверсию и средний чек за один месяц.</li>
    <li>Укажите расходы. Для 3,5% введите <b>3,5</b> или <b>3.5</b>, в зависимости от браузера.</li>
    <li>Нажмите <b>«Пересчитать все модели»</b>. Сравните результат и объём для цели. Если мощность задана, проверьте плановые слоты.</li>
   </ol>
   <div class="params-preview">
    <h3>Схема расчёта по введённым значениям</h3>
    <ol class="params-flow" aria-label="От переходов к результату месяца">
     <li><span>Переходы</span><strong data-param-preview="traffic">—</strong></li>
     <li><span>Новые покупатели</span><strong data-param-preview="buyers">—</strong></li>
     <li><span>Выручка</span><strong data-param-preview="revenue">—</strong></li>
     <li><span>Результат месяца</span><strong data-param-preview="profit">—</strong></li>
    </ol>
    <p>Схема обновляется при вводе. Результат показан до разовой подготовки. Объём с её учётом смотрите в «Экономике заказа».</p>
   </div>
   <details class="params-example">
    <summary>Разобрать расчёт на исходных значениях</summary>
    <p>${fmt(example.inputs.traffic, 2)} переходов при конверсии ${pct(example.inputs.conversion, 3)} дают ${fmt(example.buyers, 2)} новых покупателей. Объём продаж — ${fmt(example.orders, 2)} при среднем чеке ${money(example.inputs.price, 2)}.</p>
    <p>Из выручки ${money(example.revenue, 2)} вычитаются себестоимость ${money(example.orders * example.cogs, 2)}, расходы на продажи ${money(salesCosts, 2)}, реклама ${money(example.ac, 2)} и расходы месяца ${money(example.overhead, 2)}. Результат — <b>${money(example.profit, 2)}</b>.</p>
    <p>Кнопка «Вернуть исходные значения» восстановит исходный сценарий. Чтобы сохранить свой, после пересчёта нажмите «Данные модели ↓» внизу страницы.</p>
   </details>
  </section>
  <form id="params-form" class="dialog-form">
   ${fieldMarkup}
   <div class="params-actions">
    <div id="params-error" class="error" role="alert" hidden></div>
    <button class="btn primary" type="submit">Пересчитать все модели</button>
    <button class="btn" type="button" id="reset-params">Вернуть исходные значения</button>
   </div>
  </form>`);

 $('#detail').scrollTop = 0;
 const form = $('#params-form');
 const error = $('#params-error');
 const preview = [...$('#detail-content').querySelectorAll('[data-param-preview]')];

 function readInputs() {
  return Object.fromEntries(fields.map(([key]) => {
   const value = form.elements.namedItem(key).valueAsNumber;
   if (!percentFields.has(key)) return [key, value];
   return [key, value === displayed[key] ? m.inputs[key] : value / 100];
  }));
 }

 function updatePreview() {
  const inputs = readInputs();
  const valid = !form.querySelector(':invalid') && inputs.variable_rate < 1;
  const result = valid ? NicheModel.calc(m, inputs) : null;
  const values = result ? {
   traffic: fmt(result.inputs.traffic, 2),
   buyers: fmt(result.buyers, 2),
   revenue: money(result.revenue),
   profit: money(result.profit)
  } : null;
  preview.forEach(node => { node.textContent = values?.[node.dataset.paramPreview] ?? '—'; });
 }

 form.addEventListener('input', () => {
  error.hidden = true;
  updatePreview();
 });
 form.addEventListener('submit', event => {
  event.preventDefault();
  const inputs = readInputs();
  if (inputs.variable_rate >= 1) {
   error.textContent = 'Процентные статьи должны быть ниже 100%.';
   error.hidden = false;
   return;
  }
  const next = {...m, inputs: {...m.inputs, ...inputs}};
  try {
   NicheModel.validate(next);
   m = next;
   render();
   $('#detail').close();
  } catch (err) {
   error.textContent = err.message;
   error.hidden = false;
  }
 });
 $('#reset-params').addEventListener('click', () => {
  m = JSON.parse(JSON.stringify(original));
  render();
  $('#detail').close();
 });
 updatePreview();
});
render();tab(location.hash.slice(1)||'canvas');
})();

